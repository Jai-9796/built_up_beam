﻿using System.Windows.Forms;
using Tekla.Structures.Model;
using Point = Tekla.Structures.Geometry3d.Point;
using Vector = Tekla.Structures.Geometry3d.Vector;
using Tekla.Structures.Model.UI;
using Tekla.Structures;
using System;
using Render;
using Tekla.Structures.Solid;
using System.Collections.Generic;
using System.Linq;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.ModelInternal;
using Color = Tekla.Structures.Model.UI.Color;

namespace BuiltUpMemberAndAttachments
{
    public partial class Form1 : Form
    {
        public Model Model { get; set; } = new Model();


        public Form1()
        {
            InitializeComponent();

        }

        private void CreateBUP_Click(object sender, System.EventArgs e)
        {
            bool result = Model.GetConnectionStatus();
            if (result)
            {
                Beam isFlange = CreateInSideFlange();
                Beam osFlange = CreateOutSideFlange(10, 16);

                var normalVector = osFlange.GetCoordinateSystem().AxisX.Cross(osFlange.GetCoordinateSystem().AxisY).GetNormal();

                List<Point> vertices = GetAllVertices(osFlange);

                var requiredVertex = vertices.OrderBy(x => x.Z).ToList().FirstOrDefault();
       /*       Point requiredVertex2 = vertices.OrderBy(x => x.X).ToList().FirstOrDefault();
                ControlPoint controlPoint2 = new ControlPoint(requiredVertex2); */

                ControlPoint controlPoint = new ControlPoint(requiredVertex);
                controlPoint.Insert();

                GeometricPlane plane = new GeometricPlane(requiredVertex, osFlange.GetCoordinateSystem().AxisX.GetNormal());

                GeometricPlane geometricPlane = new GeometricPlane(requiredVertex, normalVector);

                GeometricPlane verticalPlane = new GeometricPlane(osFlange.StartPoint, osFlange.GetCoordinateSystem().AxisY.GetNormal());

                Tekla.Structures.Geometry3d.Line line = Intersection.PlaneToPlane(plane, geometricPlane);
                Point point1 = Intersection.LineToPlane(line, verticalPlane);
                new GraphicsDrawer().DrawText(point1, "point", new Tekla.Structures.Model.UI.Color());

                List<Point> projectedPoints = new List<Point>();
                List<Point> anotherPoints = new List<Point>();

                var orderbyZ = vertices.GroupBy(x => x.Z);
                foreach (var item in orderbyZ)
                {
                    var temp = item.FirstOrDefault();
                    anotherPoints.Add(temp);
                }


                foreach (Point point3 in anotherPoints)
                {
                    var projectedPoint = Projection.PointToPlane(point3, geometricPlane);
                    projectedPoints.Add(projectedPoint);
                }

                var anotherPoint = anotherPoints.FirstOrDefault();
                new GraphicsDrawer().DrawText(anotherPoint, "k", new Tekla.Structures.Model.UI.Color());

                GeometricPlane geometricPlane1 = new GeometricPlane(anotherPoint, osFlange.GetCoordinateSystem().AxisX.GetNormal());

                var anotherLine = Intersection.PlaneToPlane(geometricPlane, geometricPlane1);

                Point point = Intersection.LineToPlane(anotherLine, verticalPlane);
                new GraphicsDrawer().DrawText(point, "p1", new Tekla.Structures.Model.UI.Color());


                List<Point> verticesIF = GetAllVertices(isFlange);

                List<IGrouping<double, Point>> d = verticesIF.GroupBy(x => x.Z).ToList();

                List<Point> insideFlangePointList = new List<Point>();

                foreach (var item in d)
                {

                    Point f = d.FirstOrDefault() as Point;
                    insideFlangePointList.Add(f);
                }

                //new GraphicsDrawer().DrawText(insideFlangePointList[0] as Point, "s", new Tekla.Structures.Model.UI.Color());

                var listOFPointForWeb = new List<Point>();
                listOFPointForWeb.Add(point);
                listOFPointForWeb.Add(point1);
                listOFPointForWeb.AddRange(insideFlangePointList);


                CreateWeb(listOFPointForWeb, isFlange, osFlange);


            }
        }

        private List<Point> GetAllVertices(Beam osFlange)
        {
            List<Point> points = new List<Point>();

            var faceEnum = osFlange.GetSolid().GetFaceEnumerator();
            while (faceEnum.MoveNext())
            {
                var currentface = faceEnum.Current as Tekla.Structures.Solid.Face;
                var loops = currentface.GetLoopEnumerator();
                while (loops.MoveNext())
                {
                    var currentLoop = loops.Current as Loop;
                    var vertices = currentLoop.GetVertexEnumerator();
                    while (vertices.MoveNext())
                    {
                        Point vertex = vertices.Current as Point;
                        points.Add(vertex);
                    }

                }
            }

            List<Point> newlist = points.Distinct().ToList();
            return newlist;
        }

        private void CreateWeb(List<Point> listOFPointForWeb, Beam insideFlange, Beam outsideFlange)
        {
            ContourPlate CountourPlate = new ContourPlate();
            ContourPoint contourpoint1 = new ContourPoint(insideFlange.StartPoint, null);
            ContourPoint contourpoint2 = new ContourPoint(insideFlange.EndPoint, null);
            ContourPoint contourPoint3 = new ContourPoint(outsideFlange.EndPoint, null);
            ContourPoint contourpoint4 = new ContourPoint(outsideFlange.StartPoint, null);


            CountourPlate.AddContourPoint(contourpoint1);
            CountourPlate.AddContourPoint(contourpoint2);
            CountourPlate.AddContourPoint(contourPoint3);
            CountourPlate.AddContourPoint(contourpoint4);

            CountourPlate.Profile.ProfileString = "PLT12.8";
            CountourPlate.Material.MaterialString = "3000";
            CountourPlate.Insert();
            //     PL1/4*24"
            Model.CommitChanges();
            var WebFitting = insertWebFitting(insideFlange, outsideFlange, CountourPlate);


            //contourPlate.Contour = listOFPointForWeb.ToArray();
        }

        private object insertWebFitting(Beam insideFlange, Beam outsideFlange, ContourPlate CountourPlate)
        {
            CoordinateSystem insideflangecoordiantesystem = insideFlange.GetCoordinateSystem();
            GeometricPlane insideflangegeometricplane = new GeometricPlane(insideflangecoordiantesystem);
            var insideflangeOrigin = insideflangecoordiantesystem.Origin;
            var insideflangeYaxis = insideflangecoordiantesystem.AxisY;




            CoordinateSystem outsideFlangecoordinatesystem = outsideFlange.GetCoordinateSystem();
            GeometricPlane outsideflangegp = new GeometricPlane(outsideFlangecoordinatesystem);
            var outsideFlangeOrigin = outsideFlangecoordinatesystem.Origin;
            var outsideflangeYaxis = outsideFlangecoordinatesystem.AxisY;


            // contourplate system 
            CoordinateSystem contourplatecoordiantesytem = CountourPlate.GetCoordinateSystem();
            GeometricPlane contourplatecoordiantesystem = new GeometricPlane(contourplatecoordiantesytem);
            var contourorigin = contourplatecoordiantesystem.Origin;
            var contourXxis = contourplatecoordiantesytem.AxisX;
            var contourYaxis = contourplatecoordiantesytem.AxisY;
            GeometricPlane transcontourplate = new GeometricPlane(contourorigin, contourXxis);

            Tekla.Structures.Geometry3d.Line lineis = Intersection.PlaneToPlane(insideflangegeometricplane, contourplatecoordiantesystem);
            Tekla.Structures.Geometry3d.Line line2is = Intersection.PlaneToPlane(outsideflangegp, contourplatecoordiantesystem);


            DrawLine(lineis, new Color(1, 0, 0));
            DrawLine(line2is, new Color(0, 0, 1));


            new GraphicsDrawer().DrawLineSegment(new LineSegment(transcontourplate.Origin, new Point(transcontourplate.Origin + (5 * 12 * 25.4 * transcontourplate.Normal.GetNormal()))), new Color(0, 1, 0));
            new GraphicsDrawer().DrawText(transcontourplate.Origin, "Org", new Color(0, 1, 0));
            new GraphicsDrawer().DrawText(new Point(transcontourplate.Origin + (5 * 12 * 25.4 * transcontourplate.Normal.GetNormal())), "TIP", new Color(0, 1, 0));

            Point pointofinterplane = Intersection.LineToPlane(lineis, transcontourplate);
            ControlPoint  controlpoint1 = new ControlPoint(pointofinterplane);
            controlpoint1.Insert();

            Point pointfortheouter = Intersection.LineToPlane(line2is, transcontourplate);
            ControlPoint controlpoint2= new ControlPoint(pointfortheouter);
            controlpoint2.Insert();

         
            // Point to be moved to another location 
            var columndepth = 0.0;
            insideFlange.GetReportProperty("WIDTH", ref columndepth);


            var fittingPoint1 = pointofinterplane + (columndepth*0.5) *new Vector(0, 0, 1);
            controlpoint1 = new ControlPoint(fittingPoint1);    
            controlpoint1.Insert(); 


            Model model = new Model();  

            CutPlane fitting = new CutPlane();
            //Fitting fitting = new Fitting();
            fitting.Father = CountourPlate;
            fitting.Plane.Origin = fittingPoint1;
            fitting.Plane.AxisX = new Vector(-1, 0, 0);
            fitting.Plane.AxisY = new Vector(0, 1, 0);
            fitting.Insert();
            model.CommitChanges();

            List<Point> vertices = GetAllVertices(outsideFlange);

            var requiredVertex = vertices.OrderBy(x => x.Z).ToList().FirstOrDefault();

            CutPlane cutPlane = new CutPlane();
            //Fitting fitting = new Fitting();
            cutPlane.Father = CountourPlate;
            cutPlane.Plane.Origin = requiredVertex;
            cutPlane.Plane.AxisX = outsideFlange.GetCoordinateSystem().AxisX;
            cutPlane.Plane.AxisY = outsideFlange.GetCoordinateSystem().AxisY;
            cutPlane.Insert();
            model.CommitChanges();

            return fitting;

        }
  

        private bool DrawLine(Tekla.Structures.Geometry3d.Line line, Color color)
        {
            Point p1 = line.Origin + line.Direction.GetNormal() * -1 * 999 * 12 * 25.4;

            Point p2 = line.Origin + line.Direction.GetNormal() * 999 * 12 * 25.4;
            LineSegment lineSegment = new LineSegment(p1, p2);
            if (new GraphicsDrawer().DrawText(p1, "P-1", color) &&
            new GraphicsDrawer().DrawText(p2, "P-2", color) &&
            new GraphicsDrawer().DrawLineSegment(lineSegment, color))
                return true;
            return false;
        }

        private Beam CreateOutSideFlange(double startPointElevation, double endPointElevation)
        {
            var spHeight = InchToMM(startPointElevation);
            var epValue = InchToMM(endPointElevation);

            var difference = epValue - spHeight;

            Beam outsideFlange = new Beam();

            outsideFlange.Profile.ProfileString = "PL12.7*152.4";
            outsideFlange.Material.MaterialString = "A36";
            outsideFlange.Class = "6";

            outsideFlange.StartPoint = new Tekla.Structures.Geometry3d.Point(0, 0, 0) + spHeight * new Vector(0, 0, 1).GetNormal();
            Point tempPoint = outsideFlange.StartPoint + (1219.2 * new Vector(1, 0, 0).GetNormal());
            outsideFlange.EndPoint = tempPoint + difference * new Vector(0, 0, 1);
            outsideFlange.Position.Plane = Position.PlaneEnum.MIDDLE;
            outsideFlange.Position.Rotation = Position.RotationEnum.FRONT;
            outsideFlange.Position.Depth = Position.DepthEnum.BEHIND;

            outsideFlange.Insert();
            Model.CommitChanges();
            return outsideFlange;


        }

        private Beam CreateInSideFlange()
        {

            Beam insideFlange = new Beam();

            insideFlange.Profile.ProfileString = "PL12.7*152.4";
            insideFlange.Material.MaterialString = "A36";
            insideFlange.Class = "6";

            insideFlange.StartPoint = new Tekla.Structures.Geometry3d.Point(0, 0, 0);
            insideFlange.EndPoint = insideFlange.StartPoint + (1219.2 * new Vector(1, 0, 0).GetNormal());
            insideFlange.Position.Plane = Position.PlaneEnum.MIDDLE;
            insideFlange.Position.Depth = Position.DepthEnum.FRONT;
            insideFlange.Position.Rotation = Position.RotationEnum.FRONT;

            var result2 = insideFlange.Insert();
            Model.CommitChanges();
            return insideFlange;


        }

        private double InchToMM(double inInches)
        {
            return inInches * 25.4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Picker picker = new Picker();
            Part part = picker.PickObject(Picker.PickObjectEnum.PICK_ONE_PART, "Select Part") as Part;

            WorkPlaneHandler workPlaneHandler = new Model().GetWorkPlaneHandler();
            workPlaneHandler.SetCurrentTransformationPlane(new TransformationPlane(part.GetCoordinateSystem()));
            part.Select();
            DrawCoordinateSystem(part.GetCoordinateSystem(), "Org");
            workPlaneHandler.SetCurrentTransformationPlane(new TransformationPlane());
            part.Select();
        }
        private void DrawCoordinateSystem(CoordinateSystem coordinateSystem, string v)
        {

            double lengthFoot = 2.0;
            Tekla.Structures.Model.UI.GraphicsDrawer graphicsDrawer = new GraphicsDrawer();

            Point X = coordinateSystem.Origin + coordinateSystem.AxisX.GetNormal() * lengthFoot * 12 * 25.4;
            Point Y = coordinateSystem.Origin + coordinateSystem.AxisY.GetNormal() * lengthFoot * 12 * 25.4;
            Point Z = coordinateSystem.Origin + coordinateSystem.AxisX.Cross(coordinateSystem.AxisY).GetNormal() * lengthFoot * 12 * 25.4;

            graphicsDrawer.DrawText(coordinateSystem.Origin, "Origin", new Color());
            graphicsDrawer.DrawText(X, "X", new Color(1, 0, 0));
            graphicsDrawer.DrawText(Y, "Y", new Color(0, 1, 0));
            graphicsDrawer.DrawText(Z, "Z", new Color(0, 0, 1));

            graphicsDrawer.DrawLineSegment(new LineSegment(coordinateSystem.Origin, X), new Color(1, 0, 0));
            graphicsDrawer.DrawLineSegment(new LineSegment(coordinateSystem.Origin, Y), new Color(0, 1, 0));
            graphicsDrawer.DrawLineSegment(new LineSegment(coordinateSystem.Origin, Z), new Color(0, 0, 1));
        }

    }
}
