﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Tekla.Structures.Model;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model.UI;
using System.Data.Common;
using Point = Tekla.Structures.Geometry3d.Point;

using System.Collections;
using System.Net;
using System.Runtime.ConstrainedExecution;
using System.Security.Policy;
using Tekla.Structures.Solid;
using System.Runtime.InteropServices;
using System.Windows.Forms.ComponentModel.Com2Interop;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Model Model { get; set; } = new Model();

        public Picker picker { get; set; } = new Picker();



        public Form1()
        {
            InitializeComponent();
        }

        private void CreateConnection_Click(object sender, EventArgs e)
        {
            if (Model.GetConnectionStatus())
            {
                (Beam column, Beam beam) = PickColumnAndBeam();
                var isPlaneParellel = IsPlaneParellel(column, beam);
                if (isPlaneParellel)
                {
                    // Beam connected at flange
                    double columnDepth = 0.0;
                    column.GetReportProperty("HEIGHT", ref columnDepth);
                    Point midPoint = GetMidPoint(beam);
                    GeometricPlane colTP = new GeometricPlane(column.GetCoordinateSystem().Origin, column.GetCoordinateSystem().AxisY);
                    GeometricPlane beamTP = new GeometricPlane(beam.GetCoordinateSystem().Origin, beam.GetCoordinateSystem().AxisY);
                    GeometricPlane beamPlane = new GeometricPlane(beam.GetCoordinateSystem());

                    var resultingLine = Intersection.PlaneToPlane(colTP, beamTP);
                    var resultingPoint = Intersection.LineToPlane(resultingLine, beamPlane);
                    var pointOfInterset = resultingPoint + (columnDepth * 0.5) * new Vector(midPoint - resultingPoint).GetNormal();
                    ApplyCutAtFlangeOrWeb(beam, pointOfInterset);
                }
                else
                {
                    // Connected at web
                    double webThk = 0.0;
                    beam.GetReportProperty("WEB_THICKNESS", ref webThk);
                    Point midPoint = GetMidPoint(beam);
                    GeometricPlane colPlane = new GeometricPlane(column.GetCoordinateSystem());
                    GeometricPlane beamTP = new GeometricPlane(beam.GetCoordinateSystem().Origin, beam.GetCoordinateSystem().AxisY);
                    GeometricPlane beamPlane = new GeometricPlane(beam.GetCoordinateSystem());

                    var resultingLine = Intersection.PlaneToPlane(colPlane, beamTP);
                    var resultingPoint = Intersection.LineToPlane(resultingLine, beamPlane);
                    var pointOfInterset = resultingPoint + (webThk * 0.5) * new Vector(midPoint - resultingPoint).GetNormal();
                    ApplyCutAtFlangeOrWeb(beam, pointOfInterset);
                }
            }
        }

        private bool IsPlaneParellel(Beam column, Beam beam)
        {
            CoordinateSystem columnCS = column.GetCoordinateSystem();
            CoordinateSystem beamCS = beam.GetCoordinateSystem();
            GeometricPlane columnPlane = new GeometricPlane(columnCS);
            GeometricPlane beamPlane = new GeometricPlane(beamCS);
            bool isPlaneParellel = false;
            return isPlaneParellel = Tekla.Structures.Geometry3d.Parallel.PlaneToPlane(columnPlane, beamPlane);
        }

        private void ApplyCutAtFlangeOrWeb(Beam beam, Point fittingOrigin)
        {
            Fitting fitting = new Fitting();
            fitting.Father = beam;
            fitting.Plane.Origin = fittingOrigin;
            fitting.Plane.AxisX = new Vector(0, 1, 0);
            fitting.Plane.AxisY = new Vector(0, 0, 1);
            fitting.Insert();
            Model.CommitChanges();

        }

        private (Beam column, Beam beam) PickColumnAndBeam()
        {
            Beam column = picker.PickObject(Picker.PickObjectEnum.PICK_ONE_PART, "Pick a column ...!") as Beam;
            Beam beam = picker.PickObject(Picker.PickObjectEnum.PICK_ONE_PART, "Pick a beam ...!") as Beam;
            return (column, beam);
        }

        private Tekla.Structures.Geometry3d.Point GetMidPoint(Beam beam)
        {
            Tekla.Structures.Geometry3d.Point startPoint = beam.StartPoint;
            Tekla.Structures.Geometry3d.Point endPoint = beam.EndPoint;
            double firstTerm = (startPoint.X + endPoint.X) * 0.5;
            double secondTerm = (startPoint.Y + endPoint.Y) * 0.5;
            double thirdTerm = (startPoint.Z + endPoint.Z) * 0.5;
            return new Tekla.Structures.Geometry3d.Point(firstTerm, secondTerm, thirdTerm);
        }
    }
}
